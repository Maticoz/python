class Car:
    def __init__(self, mark, model, year, mileage):
        self.model      =   str(model)
        self.mark       =   str(mark)
        self.year       =   int(year)
        self.mileage    =   float(mileage)
